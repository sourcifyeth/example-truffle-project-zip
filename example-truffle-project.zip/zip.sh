zip -r example-truffle-project . -x '*.env*' -x '*node_modules*'
